import { hello } from '../hello';

export default hello;
