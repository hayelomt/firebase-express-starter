export const hello = () => 'Hello World';
