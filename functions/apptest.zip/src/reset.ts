export default () => {
  beforeEach(() => {
    console.log('before each');
  });
};
