import hello from '../util/util';
import { expect } from 'chai';
import reset from '../reset';

reset();

before(() => {
  console.log('Before');
});

describe('test hello', () => {
  it('should return hello world', () => {
    const result = hello();
    expect(result).to.equal('Hello World');
  });
});
